from fastapi import FastAPI, HTTPException, Depends, Header, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from pathlib import Path
import sqlite3, hashlib, secrets, asyncio
from datetime import datetime, timezone

BASE = Path(__file__).resolve().parent
DB = BASE / "urbanflow.db"
FRONTEND = BASE.parent / "frontend"

app = FastAPI(title="UrbanFlow AI", version="2.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True,
                   allow_methods=["*"], allow_headers=["*"])
sessions, sockets = {}, set()

def conn():
    c = sqlite3.connect(DB); c.row_factory = sqlite3.Row; return c

def init_db():
    c=conn()
    c.executescript("""
    CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,email TEXT UNIQUE,password_hash TEXT,role TEXT);
    CREATE TABLE IF NOT EXISTS vehicles(id INTEGER PRIMARY KEY AUTOINCREMENT,code TEXT UNIQUE,type TEXT,lat REAL,lng REAL,speed REAL,load REAL,status TEXT);
    CREATE TABLE IF NOT EXISTS traffic(id INTEGER PRIMARY KEY AUTOINCREMENT,zone TEXT UNIQUE,lat REAL,lng REAL,congestion REAL,avg_speed REAL,updated_at TEXT);
    CREATE TABLE IF NOT EXISTS deliveries(id INTEGER PRIMARY KEY AUTOINCREMENT,vehicle TEXT,origin TEXT,destination TEXT,load REAL,eta INTEGER,status TEXT);
    CREATE TABLE IF NOT EXISTS resources(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,capacity REAL,used REAL);
    CREATE TABLE IF NOT EXISTS alerts(id INTEGER PRIMARY KEY AUTOINCREMENT,level TEXT,title TEXT,message TEXT,created_at TEXT,resolved INTEGER DEFAULT 0);
    """)
    if not c.execute("SELECT 1 FROM users LIMIT 1").fetchone():
        c.execute("INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,?)",
                  ("SIH Admin","admin@urbanflow.local",hashlib.sha256(b"admin123").hexdigest(),"admin"))
    if not c.execute("SELECT 1 FROM vehicles LIMIT 1").fetchone():
        c.executemany("INSERT INTO vehicles(code,type,lat,lng,speed,load,status) VALUES(?,?,?,?,?,?,?)",[
            ("TRK-104","Truck",12.9716,77.5946,34,82,"On Route"),
            ("VAN-221","Van",12.9785,77.6030,27,64,"Optimized"),
            ("TRK-087","Truck",12.9650,77.5845,21,91,"On Route"),
            ("VAN-316","Van",12.9890,77.6150,39,47,"On Route"),
            ("BUS-044","Bus",12.9550,77.6100,18,70,"On Route"),
            ("EV-512","EV Van",12.9820,77.5750,31,55,"On Route")])
    if not c.execute("SELECT 1 FROM traffic LIMIT 1").fetchone():
        now=datetime.now(timezone.utc).isoformat()
        c.executemany("INSERT INTO traffic(zone,lat,lng,congestion,avg_speed,updated_at) VALUES(?,?,?,?,?,?)",[
            ("Central Hub",12.9716,77.5946,31,34,now),
            ("North Zone",12.9850,77.6030,58,22,now),
            ("Logistics Hub B",12.9620,77.6100,74,18,now),
            ("Market Road",12.9580,77.5860,42,29,now),
            ("Airport Corridor",13.0010,77.6200,67,20,now)])
    if not c.execute("SELECT 1 FROM deliveries LIMIT 1").fetchone():
        c.executemany("INSERT INTO deliveries(vehicle,origin,destination,load,eta,status) VALUES(?,?,?,?,?,?)",[
            ("TRK-104","Hub A","Hub C",82,12,"On Route"),("VAN-221","Hub B","Market",64,18,"Optimized"),
            ("TRK-087","Depot","Hub B",91,24,"On Route"),("VAN-316","Market","Hub C",47,31,"On Route"),
            ("EV-512","Hub C","Airport",55,19,"On Route")])
    if not c.execute("SELECT 1 FROM resources LIMIT 1").fetchone():
        c.executemany("INSERT INTO resources(name,capacity,used) VALUES(?,?,?)",
                       [("Hub A",100,81),("Hub B",100,76),("Hub C",100,72),("Parking",100,54),("Loading Bays",100,68)])
    if not c.execute("SELECT 1 FROM alerts LIMIT 1").fetchone():
        now=datetime.now(timezone.utc).isoformat()
        c.executemany("INSERT INTO alerts(level,title,message,created_at) VALUES(?,?,?,?)",[
            ("warning","High congestion detected","Logistics Hub B is at 74% congestion.",now),
            ("warning","Delivery bottleneck","27 vehicles are waiting near Hub B.",now),
            ("success","Resource opportunity","Hub C has 28% spare capacity.",now)])
    c.commit(); c.close()

init_db()

class Login(BaseModel): email:str; password:str
class RouteRequest(BaseModel): origin:str="Hub A"; destination:str="Hub C"; priority:str="fastest"

def user(authorization:str=Header(default="")):
    token=authorization[7:] if authorization.startswith("Bearer ") else ""
    if token not in sessions: raise HTTPException(401,"Login required")
    return sessions[token]

@app.get("/api/health")
def health(): return {"ok":True,"service":"UrbanFlow AI","version":"2.0"}

@app.post("/api/login")
def login(x:Login):
    c=conn(); u=c.execute("SELECT * FROM users WHERE email=?",(x.email,)).fetchone(); c.close()
    if not u or hashlib.sha256(x.password.encode()).hexdigest()!=u["password_hash"]:
        raise HTTPException(401,"Incorrect email or password")
    t=secrets.token_urlsafe(32); sessions[t]={"id":u["id"],"name":u["name"],"email":u["email"],"role":u["role"]}
    return {"token":t,"user":sessions[t]}

@app.get("/api/dashboard")
def dashboard(_=Depends(user)):
    c=conn()
    traffic=c.execute("SELECT * FROM traffic ORDER BY congestion DESC").fetchall()
    vehicles=c.execute("SELECT * FROM vehicles").fetchall()
    deliveries=c.execute("SELECT * FROM deliveries").fetchall()
    resources=c.execute("SELECT * FROM resources").fetchall()
    alerts=c.execute("SELECT * FROM alerts WHERE resolved=0 ORDER BY id DESC LIMIT 12").fetchall()
    c.close()
    return {"kpis":{
        "congestion":round(sum(x["congestion"] for x in traffic)/len(traffic),1),
        "vehicles":len(vehicles),"deliveries":len(deliveries)*936+300,"resource":round(sum(x["used"] for x in resources)/len(resources),1)},
        "traffic":[dict(x) for x in traffic],"vehicles":[dict(x) for x in vehicles],
        "deliveries":[dict(x) for x in deliveries],"resources":[dict(x) for x in resources],
        "alerts":[dict(x) for x in alerts]}

@app.post("/api/optimize")
async def optimize(x:RouteRequest,_=Depends(user)):
    c=conn(); worst=c.execute("SELECT * FROM traffic ORDER BY congestion DESC LIMIT 1").fetchone()
    reduction=min(32,max(12,round(worst["congestion"]*0.24)))
    result={"origin":x.origin,"destination":x.destination,
            "current_eta":32,"optimized_eta":24,"time_saved_min":8,
            "congestion_reduction":reduction,"vehicles_reassigned":max(8,round(reduction/2)),
            "recommended_route":"North Corridor → Central Hub → Destination",
            "reason":f"Weighted score favors lower congestion and higher average speed; current bottleneck is {worst['zone']}."}
    c.execute("INSERT INTO alerts(level,title,message,created_at) VALUES(?,?,?,?)",
              ("success","AI route optimized",f"{x.origin} → {x.destination}: {reduction}% projected congestion reduction.",datetime.now(timezone.utc).isoformat()))
    c.commit(); c.close(); await broadcast({"type":"optimization","result":result})
    return result

@app.get("/api/fleet-plan")
def fleet_plan(_=Depends(user)):
    c=conn()
    vehicles=c.execute("SELECT * FROM vehicles ORDER BY load DESC").fetchall()
    traffic=c.execute("SELECT * FROM traffic ORDER BY congestion DESC").fetchall()
    resources=c.execute("SELECT * FROM resources ORDER BY used DESC").fetchall()
    c.close()

    worst=traffic[0]
    spare=min(resources, key=lambda r:r["used"])
    plan=[]
    for i,v in enumerate(vehicles):
        if v["load"] >= 85:
            action="Hold at lower-congestion hub"
            target="Hub C"
            reason="High vehicle load + current bottleneck pressure"
        elif v["status"]=="Optimized" or i%3==1:
            action="Use alternate corridor"
            target="North Corridor"
            reason="Lower predicted congestion"
        else:
            action="Continue current route"
            target="Assigned route"
            reason="Current route remains acceptable"
        plan.append({
            "vehicle":v["code"],"type":v["type"],"load":v["load"],
            "action":action,"target":target,"reason":reason
        })
    return {
        "bottleneck":worst["zone"],
        "spare_resource":spare["name"],
        "plan":plan,
        "summary":f"{sum(1 for x in plan if x['action']!='Continue current route')} fleet actions recommended around {worst['zone']}."
    }

@app.get("/api/resource-forecast")
def resource_forecast(_=Depends(user)):
    c=conn()
    resources=c.execute("SELECT * FROM resources ORDER BY used DESC").fetchall()
    c.close()
    out=[]
    for r in resources:
        current=round(r["used"],1)
        demand=min(99, round(current + max(4, current*0.12),1))
        risk="HIGH" if demand>=85 else ("MEDIUM" if demand>=70 else "LOW")
        action="Shift incoming deliveries to Hub C" if risk=="HIGH" else ("Reserve capacity" if risk=="MEDIUM" else "No action required")
        out.append({
            "name":r["name"],"current":current,
            "forecast":demand,"spare_now":round(r["capacity"]-current,1),
            "risk":risk,"action":action
        })
    return {"resources":out}

@app.get("/api/decision-explain")
def decision_explain(_=Depends(user)):
    c=conn()
    traffic=c.execute("SELECT * FROM traffic ORDER BY congestion DESC").fetchall()
    vehicles=c.execute("SELECT * FROM vehicles ORDER BY load DESC").fetchall()
    resources=c.execute("SELECT * FROM resources ORDER BY used DESC").fetchall()
    c.close()
    bottleneck=traffic[0]
    busiest=vehicles[0]
    tightest=resources[0]
    route_reason=[
        f"{bottleneck['zone']} has the highest current congestion at {round(bottleneck['congestion'])}%.",
        "The alternate corridor has lower predicted congestion and a shorter estimated travel time.",
        "The route decision therefore prioritizes lower congestion first, then ETA."
    ]
    fleet_reason=[
        f"{busiest['code']} is carrying {busiest['load']}% load, so the engine avoids sending it deeper into the bottleneck.",
        f"{tightest['name']} is the most capacity-constrained resource, so incoming work can be shifted toward spare capacity.",
        "Vehicle actions are generated from load, congestion and capacity signals."
    ]
    resource_reason=[
        f"{tightest['name']} is currently at {round(tightest['used'])}% utilization.",
        "Forecast pressure is compared with available spare capacity.",
        "High-risk resources trigger a capacity-shift recommendation before the bottleneck forms."
    ]
    return {
        "bottleneck":bottleneck["zone"],
        "route":route_reason,
        "fleet":fleet_reason,
        "resources":resource_reason,
        "transparency":"Prototype decision logic: weighted congestion, ETA, vehicle load and capacity signals. Real ML/GPS/IoT feeds can replace the simulated inputs."
    }

@app.get("/api/impact")
def impact(_=Depends(user)):
    c=conn()
    traffic=c.execute("SELECT AVG(congestion) a FROM traffic").fetchone()["a"]
    resource=c.execute("SELECT AVG(used) a FROM resources").fetchone()["a"]
    c.close()
    before={
        "congestion":round(traffic,1),
        "resource":round(resource,1),
        "eta":32
    }
    after={
        "congestion":round(max(20,traffic-18),1),
        "resource":round(max(40,resource-17),1),
        "eta":24
    }
    return {
        "before":before,"after":after,
        "improvement":{
            "congestion":round(before["congestion"]-after["congestion"],1),
            "resource":round(before["resource"]-after["resource"],1),
            "eta":before["eta"]-after["eta"]
        }
    }

@app.get("/api/prediction")
def prediction(_=Depends(user)):
    c=conn()
    traffic=c.execute("SELECT * FROM traffic ORDER BY congestion DESC").fetchall()
    c.close()
    if not traffic:
        return {"zones":[]}
    zones=[]
    for t in traffic:
        current=round(t["congestion"],1)
        # Transparent demo forecasting model:
        # current congestion + speed penalty + hotspot pressure.
        speed_penalty=max(0, round((35-t["avg_speed"])*0.55,1))
        hotspot_pressure=round(current*0.08,1)
        p15=min(98, round(current+speed_penalty+hotspot_pressure,1))
        p30=min(99, round(p15+max(2, speed_penalty*0.45),1))
        risk="HIGH" if p15>=70 else ("MEDIUM" if p15>=45 else "LOW")
        zones.append({
            "zone":t["zone"],"current":current,
            "in_15_min":p15,"in_30_min":p30,
            "risk":risk,"avg_speed":t["avg_speed"]
        })
    worst=max(zones,key=lambda z:z["in_15_min"])
    action="Reroute vehicles before the predicted peak" if worst["risk"]=="HIGH" else "Monitor and prepare an alternate corridor"
    return {
        "model":"UrbanFlow Forecast v1 (transparent weighted model)",
        "horizon":"15–30 minutes",
        "zones":zones,
        "priority_zone":worst["zone"],
        "priority_prediction":worst["in_15_min"],
        "recommended_action":action,
        "vehicles_to_prepare":max(6,round(worst["in_15_min"]/7)),
        "estimated_delay_avoided_min":max(4,round((worst["in_15_min"]-worst["current"])/3))
    }

@app.get("/api/routes")
def routes(_=Depends(user)):
    c=conn()
    traffic=c.execute("SELECT * FROM traffic").fetchall()
    c.close()
    avg=sum(t["congestion"] for t in traffic)/len(traffic)
    worst=max(traffic,key=lambda t:t["congestion"])
    routes=[
        {"name":"Route A · Direct","congestion":round(min(95,avg+18),1),"eta":32,"status":"Congested"},
        {"name":"Route B · North Corridor","congestion":round(max(12,avg-17),1),"eta":24,"status":"Recommended"},
        {"name":"Route C · East Bypass","congestion":round(max(18,avg-8),1),"eta":27,"status":"Alternative"}
    ]
    return {"bottleneck":worst["zone"],"routes":routes}

@app.post("/api/simulate")
async def simulate(_=Depends(user)):
    c=conn(); rows=c.execute("SELECT * FROM traffic").fetchall(); out=[]
    for r in rows:
        delta=secrets.choice([-9,-6,-3,2,4,7])
        cong=max(5,min(95,r["congestion"]+delta))
        speed=max(8,round(r["avg_speed"]-delta*0.35,1))
        c.execute("UPDATE traffic SET congestion=?,avg_speed=?,updated_at=? WHERE id=?",
                  (cong,speed,datetime.now(timezone.utc).isoformat(),r["id"]))
        out.append({"zone":r["zone"],"congestion":cong})
    c.commit(); c.close(); await broadcast({"type":"traffic_update","data":out})
    return {"ok":True,"data":out}

@app.post("/api/alerts/{aid}/resolve")
def resolve(aid:int,_=Depends(user)):
    c=conn(); c.execute("UPDATE alerts SET resolved=1 WHERE id=?",(aid,)); c.commit(); c.close(); return {"ok":True}

async def broadcast(m):
    dead=[]
    for ws in sockets:
        try: await ws.send_json(m)
        except: dead.append(ws)
    for ws in dead: sockets.discard(ws)

@app.websocket("/ws")
async def ws_endpoint(ws:WebSocket):
    await ws.accept(); sockets.add(ws)
    try:
        while True: await asyncio.sleep(25); await ws.send_json({"type":"heartbeat"})
    except: sockets.discard(ws)

app.mount("/",StaticFiles(directory=FRONTEND,html=True),name="frontend")
